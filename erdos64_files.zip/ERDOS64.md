# Erdős–Gyárfás conjecture: search tools and results

The conjecture: every finite graph with minimum degree at least 3 contains a cycle whose length is a power of two (4, 8, 16, 32, …). These tools check small graphs exhaustively, search heuristically for counterexamples, test an exact "necklace" construction for counterexamples, and explore the diameter-3 case.

**Status: no counterexample, no proof.** The exhaustive results below are complete for the classes stated. The heuristic results only report what a time-limited search found; they prove nothing. See the literature update at the end: a September 2026 paper verified the conjecture for every graph with at most 40 vertices, which supersedes several comparisons made here.

## Quick start

```bash
sudo apt-get install nauty            # provides nauty-geng
gcc -O3 -march=native -o eg eg.c -lm
./eg test                             # cycle-counter self-test
nauty-geng -c -f -d3 -q 14 | ./eg filter
```

`./run_all.sh` reproduces every experiment below (about half an hour on one core). `./gadget_parallel.sh` runs the gadget search on all cores of a bigger machine (see "Running the gadget search on a bigger machine"). Downloaded scripts lose their execute permission, so run them as `bash script.sh`.

## Files

| File | Contents |
|---|---|
| `eg.c` | all tools in one C file (graphs up to 64 vertices) |
| `run_all.sh` | reproduces every experiment |
| `results_log.txt` | raw output of the original run |
| `crosscheck.py`, `count_main.c` | cross-check of the cycle counter against networkx |
| `gadget_parallel.sh` | parallel, resumable version of the gadget search for multi-core machines |
| `diam_sat.py` | SAT encoding for the cubic diameter-4 question (correct but impractical; see Results 4) |
| `diam3_sms.py` | SAT Modulo Symmetries search: min degree 3, max degree ≤ Δ, diameter ≤ 2 or 3, forbidden cycle lengths (Results 5) |
| `build_sms.sh` | builds SAT Modulo Symmetries with the Glasgow Subgraph Solver at the tested, pinned versions |
| `run_slice_parallel.sh` | runs `diam3_sms.py` for a range of sizes, one per core, resumable |
| `grapher_petersen.txt`, `grapher_graph24.txt`, `grapher_preview.png` | one-equation 3D drawings of two graphs for Apple's Grapher, plus a preview |

## Modes

| Command | What it does |
|---|---|
| `./eg test` | exact cycle counts on K4, K3,3, Q3, Petersen, Heawood |
| `./eg filter [-v]` | reads graph6 from stdin; tallies graphs by diameter; counts those with no C4 and no C8; prints any graph with no power-of-two cycle |
| `./eg spectrum` | lists every cycle length present in each input graph |
| `./eg gadget [NMAX] [-v]` | exact necklace test on gadgets read from stdin (see Results 2) |
| `./eg hsearch N SECONDS SEED` | annealing search for the bipartite "Route 1" family |
| `./eg gsearch SECONDS SEED MAXDIAM DEGSPEC` | annealing search over connected graphs with a given degree sequence (e.g. `3x24`, `3x20,4x4`), optional diameter cap (0 = none) |

The cycle counter finds each cycle from its smallest vertex and prunes paths that can no longer close in time. It reproduces the known counts on the test graphs and matched networkx exactly on 300 random graphs.

## Results (29 Sep 2026, one CPU core)

### 1. Small graphs (exhaustive)

Every graph with minimum degree ≥ 3 on at most 16 vertices has a 4-cycle or an 8-cycle. (Below 8 vertices a C4-free graph with minimum degree 3 cannot exist.)

| Vertices | Connected C4-free graphs, min degree ≥ 3 | Of those, with no C8 |
|---|---|---|
| 8, 9 | 0 | – |
| 10 | 5 | 0 |
| 11 | 9 | 0 |
| 12 | 57 | 0 |
| 13 | 503 | 0 |
| 14 | 6,059 | 0 |
| 15 | 91,433 | 0 |
| 16 | 1,655,659 | 0 |

Every connected cubic graph on 18 vertices (2,761 C4-free ones), 20 vertices (36,101) and 22 vertices (553,227, run in 8 pieces) also has a 4- or 8-cycle. So the smallest cubic graph with neither has at least 24 vertices; Markström's example has exactly 24.

**Corollary: every cubic graph of diameter ≤ 3 contains a 4-cycle or an 8-cycle.** A cubic graph of diameter ≤ 3 has at most 20 vertices: the counting (Moore) bound gives 22, a 22-vertex example would be a Moore graph of diameter 3, which does not exist, and cubic graphs have even order. This is a small result and probably implicit in Markström's 2004 computations, but it settles one piece of the diameter-3 question.

### 2. Necklace gadgets (exhaustive)

A *gadget* K has exactly two vertices u, w of degree 2; every other vertex has degree ≥ 3. Join N copies of K in a ring, w of each copy to u of the next, so every vertex has degree ≥ 3. A cycle that uses one connecting edge must use all of them (any two connecting edges form an edge cut), so it crosses each copy exactly once along a u–w path. Its length is N + ℓ₁ + … + ℓ_N, with each ℓ in P = {lengths of u–w paths in K}. Every other cycle lies inside one copy.

So if K has no power-of-two cycle and, for some N, no power of two lies in N + (sums of N elements of P), the ring is a counterexample. For instance, if every ℓ lies between a and 2a, a suitable N puts every ring cycle strictly between two consecutive powers of two. `./eg gadget` computes P exactly and tests every N ≤ 1000.

A gadget with at most 15 vertices cannot contain a 16-cycle, so it only has to avoid 4- and 8-cycles.

| Gadget vertices | Gadgets (C4-free, exactly two of degree 2) | Avoid C4 and C8 | Give a counterexample |
|---|---|---|---|
| 10 / 12 / 14 (subcubic) | 11 / 75 / 677 | 0 | 0 |
| 16 / 18 (subcubic) | 7,639 / 101,546 | 0 | 0 |
| 20 (subcubic) | 1,533,261 | 3 (all contain a 16-cycle) | 0 |
| 11 / 13 / 15 (one vertex of degree 4) | 73 / 1,228 / 21,104 | 0 | 0 |

The construction is not vacuous. Petersen minus an edge has u–w path lengths {4, 5, 7, 8}, so a ring of 7 copies would put every ring cycle between 35 and 63. It fails only because 8-cycles remain inside the gadget.

### 3. Heuristic searches (what was found, not proofs)

**Route 1 (bipartite H plus one edge): dead end.** Bipartite graphs have only even cycles, so powers of two are everywhere.

| Vertices | Result |
|---|---|
| 32 / 40 / 48 | never removed all C4 and C8 (13 / 4 / 3 left) |
| 56 | found; 3,156 sixteen-cycles |
| 63 | found; 16-cycles reduced from 2,806 to 2,583 |

**General cubic graphs** with no C4 and no C8, minimizing the number of 16-cycles:

| Vertices | Fewest 16-cycles found | Its diameter |
|---|---|---|
| 24 | 207 (another run: 330) | 5 |
| 28 | 345 | 6 |
| 32 | 236 | 7 |
| 40 | 142 | 9 |

Two of the 24-vertex graphs found are non-planar, so they differ from Markström's planar example (graph6 strings in `results_log.txt`).

**Diameter.**

- Diameter ≤ 3, ten degree sequences on 18–26 vertices: no graph avoiding C4 and C8 was found. Control: with no diameter cap the same degree sequences also failed, so these runs say nothing about diameter.
- Cubic, diameter ≤ 5: found in 0.3 s at 24 vertices.
- Cubic, diameter ≤ 4: never found at 24, 26, 28, 30, 32, 36 or 40 vertices; every run stalled with 3–4 bad cycles left, in two independent runs. This suggests, but does not prove, that **every cubic graph of diameter ≤ 4 contains a 4- or 8-cycle**.
  - A cubic graph of diameter 4 has at most 38 vertices (Buset, Discrete Appl. Math. 101, 2000).
  - Proven here up to 22 vertices (exhaustive, Results 1).
  - The two known 38-vertex cubic graphs of diameter 4 (Alegre–Fiol–Yebra/von Conta, and Doty) have no 4-cycle but 32 and 30 eight-cycles.
  - Open for 24–36 vertices. This strengthened form no longer matters for the conjecture itself (see the literature update).

### 4. SAT attempt (did not scale)

`diam_sat.py N D CASE` asks a SAT solver (CaDiCaL via PySAT) for a cubic graph on N vertices with diameter ≤ D and no 4- or 8-cycle. It fixes vertex 0's neighbourhood two steps out (two cases), forbids every 4-cycle and every 8-cycle through vertex 0 directly, and forbids other 8-cycles lazily. Each solver call takes milliseconds, but each blocks only the few 8-cycles of one labelled graph, and relabelled variants keep coming back: it did not finish even at 20 vertices, where the answer is known. The right tool is SAT Modulo Symmetries (Kirchweger–Szeider), which discards relabelled copies automatically.

### 5. Diameter 3, maximum degree 4 (SAT Modulo Symmetries, complete answers)

Target statement: every graph with minimum degree ≥ 3 and diameter ≤ 3 contains a 4-cycle or an 8-cycle (the next case after Carr's diameter-2 theorem). Graphs on at most 23 vertices are settled (arXiv:2609.04686). A graph of diameter ≤ 3 and maximum degree Δ has at most 1 + Δ + Δ(Δ−1) + Δ(Δ−1)² vertices, so the case Δ ≤ 4 is finite: sizes 24 to 53.

`diam3_sms.py` asks SAT Modulo Symmetries (smsg with the Glasgow Subgraph Solver, following the published 31-vertex pipeline) for a graph with min degree 3, max degree 4, diameter ≤ 3 and no 4- or 8-cycle. SMS generates graphs up to isomorphism, so "no graph" is a complete answer for that size (up to solver correctness; `--lrat FILE` writes a checkable proof).

Validation. With only 4-cycles forbidden, SMS must find exactly the graphs nauty finds (connected, C4-free, degrees 3–4):

| Vertices | 10 | 11 | 12 | 13 |
|---|---|---|---|---|
| diameter ≤ 2: nauty / SMS | 1 / 1 | 0 / 0 | 0 / 0 | 1 / 1 |
| diameter ≤ 3: nauty / SMS | 5 / 5 | 9 / 9 | 47 / 47 | 342 / 342 |

Results (forbidding 4- and 8-cycles; one core):

| Vertices | 18 | 21 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 |
|---|---|---|---|---|---|---|---|---|---|---|
| graphs found | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| time | 9 s | 23 s | 55 s | 70 s | 91 s | 115 s | 119 s | 142 s | 164 s | 195 s |

Sizes up to 23 agree with the published theorem. Sizes 24–30 are, as far as we know, new: the published 40-vertex verification only guarantees some power-of-two cycle, not a 4- or 8-cycle. Sizes 31–53 remain. Time grew about 1.3-fold per vertex up to 26 and about 1.15-fold after that; extrapolating, the top sizes may take hours to a day each on one core; `run_slice_parallel.sh` runs one size per core.

To run on your machine: `bash build_sms.sh` (Ubuntu/Debian; on a Mac, use a Linux virtual machine or container), then `bash run_slice_parallel.sh 31 53`. The build pins the Glasgow Subgraph Solver to commit abd331a: the latest version crashes with SMS.

## Literature update (30 Sep 2026)

- Ducoffe and a coauthor, *Towards a more structured search for Erdős–Gyárfás counter-examples*, arXiv:2609.28594 (23 Sep 2026), report verifying the conjecture for every graph of order at most 40, every bipartite graph of order at most 66 and every cubic graph of order at most 48, using SAT Modulo Symmetries. They also prove that more than 2/3 of the vertices of a minimal counterexample have degree 3 (improving Carr's 4/7).
- Balaji, *Verifying the Erdős–Gyárfás Conjecture up to 31 Vertices with SAT Modulo Symmetries* (Zenodo, 2026); code at github.com/ArjunBalaji79/erdos-gyarfas-min-degree-3.
- Consequences for this work: the conjecture itself now holds for every cubic graph of diameter ≤ 4 (they have at most 38 vertices), so the cubic diameter-4 statement above is only a curiosity. A necklace counterexample, on the other hand, would be far larger than 40 vertices, so the gadget search is not made redundant.

## Running the gadget search on a bigger machine

```bash
./gadget_parallel.sh 22            # all gadgets on 22 vertices, degrees 2,2,3,...,3, all cores
./gadget_parallel.sh 17 1          # 17 vertices with one vertex of degree 4
./gadget_parallel.sh 24 0 256 32   # 24 vertices, 256 pieces, 32 at a time
```

The run is resumable: interrupt it and run the same command again. Single-core times measured here, which grow about 20-fold per two extra vertices: 18 vertices 10 s, 20 vertices 3.5 min. Extrapolated: 22 vertices about 1 hour, 24 about 1 day, 26 about 3 weeks, all divided by the number of cores. Gadgets with degree-4 vertices are costlier (the generator produces many graphs that are then discarded). Beyond about 26 vertices, SAT Modulo Symmetries (see Balaji's repository) is the better tool.

## Drawing graphs in Grapher (macOS)

`grapher_petersen.txt` and `grapher_graph24.txt` each hold one equation of the form `(x, y, z) = (…, …, …)` that draws a whole graph as a single 3D curve: a closed walk through every edge (a few edges twice), written in each coordinate as a piecewise-linear function a + b·t + Σ dₖ·abs(t − k). In Grapher, create a new 3D graph, paste the line as a new equation (or start from Grapher's 3D parametric-curve template and paste the three components), and set t from 0 to 20 for the Petersen graph or 0 to 48 for the 24-vertex graph. The curves pass exactly through every vertex and trace every edge (checked numerically); `grapher_preview.png` shows the expected picture. The 24-vertex graph is cubic with no 4- or 8-cycle: it has every cycle length from 3 to 24 except 4 and 8.

## Next steps

1. Finish the max-degree-4 diameter-3 case: sizes 31–53 with `run_slice_parallel.sh` (Results 5). All "no graph" would prove that every graph with minimum degree 3, maximum degree 4 and diameter 3 has a 4- or 8-cycle.
2. Necklace gadgets on 22–26 vertices with `gadget_parallel.sh`, and with several degree-4 vertices; beyond that, an SMS encoding. This is the only route here that could produce a counterexample.
3. Diameter 3 in general: adapt Carr's diameter-2 case analysis (arXiv:2508.19302), which grows a subgraph from one edge using common neighbours until a C4 or C8 closes. At diameter 3, "common neighbour" weakens to "joined by a path of length ≤ 3". Graphs of diameter 3 with maximum degree Δ have at most 1 + Δ + Δ(Δ−1) + Δ(Δ−1)² vertices, so the cubic case is finite (settled above) and the real difficulty is unbounded maximum degree.
4. (Dropped) The cubic diameter-4 statement: finite and no longer relevant to the conjecture.

## Caveats

The exhaustive results depend on nauty's `geng` (standard and widely used) and on this cycle checker (validated as described above). The searches are time-limited simulated annealing: "not found" means not found, not "does not exist". Nothing here has been peer reviewed; verify independently before relying on or citing it.
