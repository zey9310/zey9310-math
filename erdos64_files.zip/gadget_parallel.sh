#!/bin/bash
# gadget_parallel.sh K [J] [PARTS] [JOBS]
#
# Exhaustive necklace-gadget search on K vertices, using every CPU core.
#   K     gadget order (number of vertices)
#   J     number of degree-4 vertices (default 0: every vertex except u,w has degree 3)
#   PARTS how many independent pieces to split the enumeration into (default 64)
#   JOBS  how many pieces to run at once (default: all cores)
# A gadget has exactly two vertices of degree 2 and no 4-cycle; see README.md, Results 2.
# The run is resumable: finished pieces are skipped if you start the same command again.
# Needs: nauty-geng, and ./eg compiled from eg.c (gcc -O3 -march=native -o eg eg.c -lm).
set -e
K=$1; J=${2:-0}; PARTS=${3:-64}; JOBS=${4:-$(nproc)}
[ -z "$K" ] && { echo "usage: $0 K [J] [PARTS] [JOBS]"; exit 1; }
TWO_M=$((3*K - 2 + J))
[ $((TWO_M % 2)) -ne 0 ] && { echo "3K-2+J must be even (odd K needs odd J)"; exit 1; }
M=$((TWO_M / 2)); MAXD=3; [ "$J" -gt 0 ] && MAXD=4
DIR=gadgets_K${K}_J${J}; mkdir -p "$DIR"
echo "K=$K vertices, J=$J degree-4 vertices, $M edges; $PARTS pieces, $JOBS at a time -> $DIR/"
seq 0 $((PARTS-1)) | xargs -P "$JOBS" -I{} bash -c "
  [ -f $DIR/part{}.done ] && exit 0
  nauty-geng -c -f -d2 -D$MAXD -q $K $M:$M {}/$PARTS | ./eg gadget > $DIR/part{}.log
  touch $DIR/part{}.done"
DONE=$(ls "$DIR"/*.done 2>/dev/null | wc -l)
echo "pieces finished: $DONE/$PARTS"
grep -h SUMMARY "$DIR"/part*.log | awk '{for(i=2;i<=NF;i++){n=split($i,a,"="); if(n==2 && a[2] ~ /^[0-9]+$/) s[a[1]]+=a[2]}}
  END{printf "TOTAL graphs=%d gadgets=%d no-C4-no-C8=%d no-internal-power-of-two-cycle=%d undecided=%d necklace-counterexamples=%d\n",
      s["graphs"], s["two-deg2-gadgets"], s["no-C4-no-C8"], s["no-internal-2^k-cycle"], s["undecided"], s["necklace-counterexamples"]}'
grep -h '!!!' "$DIR"/part*.log || echo "no necklace counterexample found"
