/*
 * eg.c - computational tools for exploring the Erdos-Gyarfas conjecture:
 *        every graph with minimum degree >= 3 has a cycle of length 4, 8, 16, 32, ...
 *
 * Build:  gcc -O3 -march=native -o eg eg.c -lm
 *
 * Modes
 *   ./eg test
 *       Self-test of the cycle counter on graphs with known cycle counts.
 *   ./eg filter [-v]
 *       Reads graph6 from stdin (e.g. `nauty-geng -c -f -d3 15 | ./eg filter`).
 *       Tallies graphs by diameter, counts graphs with no C4 and no C8, and prints
 *       any graph with no power-of-two cycle at all (a counterexample). -v prints
 *       every C4- and C8-free graph.
 *   ./eg spectrum
 *       Reads graph6 from stdin; prints diameter, degrees and all cycle lengths present.
 *   ./eg gadget [NMAX] [-v]
 *       Reads graph6 gadgets from stdin (exactly two degree-2 vertices u, w; others >= 3),
 *       e.g. `nauty-geng -c -f -d2 -D3 14 20:20 | ./eg gadget`. Tests exactly whether a ring
 *       of N <= NMAX copies would be a counterexample (see the comment above gadget_mode).
 *   ./eg hsearch N SECONDS SEED
 *       Route 1: bipartite H with two same-side vertices u=0, w=1 of degree 2 and all
 *       other degrees >= 3. If H has no cycle of length 2^k, then H + uw is a
 *       counterexample (every cycle through uw is odd). Degrees: even N -> |X|=|Y|,
 *       vertices 2,3 of X have degree 4; odd N -> |X|=|Y|+1, first vertex of Y has
 *       degree 4 (edge counting forces some vertex of degree >= 4).
 *   ./eg gsearch SECONDS SEED MAXDIAM DEGSPEC
 *       Connected graphs with a fixed degree sequence, e.g. DEGSPEC = 3x24 or 3x20,4x4,
 *       optionally restricted to diameter <= MAXDIAM (0 = no restriction).
 *
 * Search = simulated annealing with degree-preserving edge swaps.
 * Phase 1 drives the number of 4- and 8-cycles to zero (plus the diameter constraint).
 * Phase 2 keeps those at zero and minimises the number of 16-cycles; if it reaches 0,
 * longer powers of two are checked exactly and a counterexample would be printed.
 * Heuristic search: "best found" is an upper bound on the true minimum, not a proof.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <math.h>

#define MAXN 64
#define MAXE (MAXN * MAXN / 2)
#define INF 1000
#define BIT(i) (1ULL << (i))
typedef uint64_t set_t;

typedef struct { int n; set_t adj[MAXN]; } graph;

static inline int has_edge(const graph *g, int a, int b) { return (int)((g->adj[a] >> b) & 1ULL); }
static inline void add_edge(graph *g, int a, int b) { g->adj[a] |= BIT(b); g->adj[b] |= BIT(a); }
static inline void del_edge(graph *g, int a, int b) { g->adj[a] &= ~BIT(b); g->adj[b] &= ~BIT(a); }
static inline int degree(const graph *g, int v) { return __builtin_popcountll(g->adj[v]); }
static inline set_t fullset(int n) { return n >= 64 ? ~0ULL : BIT(n) - 1; }
static inline set_t above(int s) { return s >= 63 ? 0ULL : (~0ULL << (s + 1)); }
static void mk_empty(graph *g, int n) { memset(g, 0, sizeof *g); g->n = n; }

static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + 1e-9 * t.tv_nsec; }

/* xorshift64* */
static uint64_t rs = 0x9E3779B97F4A7C15ULL;
static inline uint64_t rnd(void) { rs ^= rs >> 12; rs ^= rs << 25; rs ^= rs >> 27; return rs * 2685821657736338717ULL; }
static inline int rndint(int k) { return (int)(rnd() % (uint64_t)k); }
static inline double rnd01(void) { return (double)(rnd() >> 11) * (1.0 / 9007199254740992.0); }

/* ---------------- BFS / diameter ---------------- */
static void bfs(const graph *g, int s, set_t allowed, int *dist) {
    for (int i = 0; i < g->n; i++) dist[i] = INF;
    dist[s] = 0;
    set_t seen = BIT(s), fr = BIT(s);
    for (int d = 1; fr; d++) {
        set_t nx = 0;
        for (set_t f = fr; f; f &= f - 1) nx |= g->adj[__builtin_ctzll(f)];
        nx &= allowed & ~seen;
        for (set_t t = nx; t; t &= t - 1) dist[__builtin_ctzll(t)] = d;
        seen |= nx;
        fr = nx;
    }
}

static int diameter(const graph *g) { /* -1 if disconnected */
    int dist[MAXN], diam = 0;
    set_t all = fullset(g->n);
    for (int s = 0; s < g->n; s++) {
        bfs(g, s, all, dist);
        for (int v = 0; v < g->n; v++) {
            if (dist[v] >= INF) return -1;
            if (dist[v] > diam) diam = dist[v];
        }
    }
    return diam;
}

/* ---------------- cycles of an exact length ----------------
 * Each cycle is found from its smallest vertex s, inside the subgraph on {s} + {v > s}.
 * BFS distances back to s prune paths that cannot close in time.
 * Counting mode (stop_at == 0) counts each cycle once (direction fixed by
 * requiring last vertex > first vertex). Existence mode stops at the first hit. */
typedef struct {
    const graph *g;
    int L, s, first, dedup, aborted;
    set_t allowed, visited;
    int dist[MAXN];
    long long count, stop_at, nodes, budget;
} cctx;

static void cdfs(cctx *c, int v, int d) {
    if (c->budget && ++c->nodes > c->budget) { c->aborted = 1; return; }
    if (d == c->L - 1) { /* pruning guarantees v ~ s */
        if (!c->dedup || v > c->first) c->count++;
        return;
    }
    int rem = c->L - d - 1;
    for (set_t cand = c->g->adj[v] & c->allowed & ~c->visited; cand; cand &= cand - 1) {
        int x = __builtin_ctzll(cand);
        if (c->dist[x] > rem) continue;
        c->visited |= BIT(x);
        cdfs(c, x, d + 1);
        c->visited &= ~BIT(x);
        if (c->aborted || (c->stop_at && c->count >= c->stop_at)) return;
    }
}

static long long cycles(const graph *g, int L, long long stop_at, long long budget, int *aborted) {
    cctx c;
    memset(&c, 0, sizeof c);
    c.g = g; c.L = L; c.stop_at = stop_at; c.budget = budget; c.dedup = (stop_at == 0);
    set_t all = fullset(g->n);
    if (L >= 3) {
        for (int s = 0; s + L <= g->n; s++) {
            c.allowed = above(s) & all;
            set_t nb = g->adj[s] & c.allowed;
            if (__builtin_popcountll(nb) < 2) continue;
            bfs(g, s, c.allowed, c.dist);
            c.s = s;
            for (; nb; nb &= nb - 1) {
                int x = __builtin_ctzll(nb);
                c.first = x;
                c.visited = BIT(s) | BIT(x);
                cdfs(&c, x, 1);
                if (c.aborted || (c.stop_at && c.count >= c.stop_at)) goto done;
            }
        }
    }
done:
    if (aborted) *aborted = c.aborted;
    return c.count;
}
static long long count_cyc(const graph *g, int L) { return cycles(g, L, 0, 0, NULL); }
/* 1 = has an L-cycle, 0 = has none, -1 = undecided within node budget (0 = unlimited) */
static int has_cyc(const graph *g, int L, long long budget) {
    int ab = 0;
    long long c = cycles(g, L, 1, budget, &ab);
    if (c > 0) return 1;
    return ab ? -1 : 0;
}

/* ---------------- graph6 ---------------- */
static int read_g6(const char *line, graph *g) {
    const unsigned char *p = (const unsigned char *)line;
    if (p[0] == '>') { const char *q = strstr(line, "<<"); if (!q) return -1; p = (const unsigned char *)q + 2; }
    if (*p == ':' || *p == ';' || *p == '&') return -1;
    int n;
    if (p[0] == 126) { if (p[1] == 126) return -1; n = ((p[1] - 63) << 12) | ((p[2] - 63) << 6) | (p[3] - 63); p += 4; }
    else { n = p[0] - 63; p += 1; }
    if (n < 0 || n > MAXN) return -1;
    mk_empty(g, n);
    int k = 6, val = 0;
    for (int j = 1; j < n; j++)
        for (int i = 0; i < j; i++) {
            if (k == 6) { if (*p < 63 || *p > 126) return -1; val = *p++ - 63; k = 0; }
            if ((val >> (5 - k)) & 1) add_edge(g, i, j);
            k++;
        }
    return n;
}

static void write_g6(const graph *g, char *out) {
    int n = g->n, pos = 0;
    if (n <= 62) out[pos++] = (char)(n + 63);
    else { out[pos++] = 126; out[pos++] = (char)(((n >> 12) & 63) + 63); out[pos++] = (char)(((n >> 6) & 63) + 63); out[pos++] = (char)((n & 63) + 63); }
    int k = 0, val = 0;
    for (int j = 1; j < n; j++)
        for (int i = 0; i < j; i++) {
            val = (val << 1) | has_edge(g, i, j);
            if (++k == 6) { out[pos++] = (char)(val + 63); k = 0; val = 0; }
        }
    if (k > 0) out[pos++] = (char)((val << (6 - k)) + 63);
    out[pos] = 0;
}

/* ---------------- self-test ---------------- */
static int check_counts(const char *name, const graph *g, const long long *exp) {
    int ok = 1;
    printf("%-9s n=%2d:", name, g->n);
    for (int L = 3; L <= g->n; L++) {
        long long c = count_cyc(g, L);
        int h = has_cyc(g, L, 0);
        if (c != exp[L] || h != (exp[L] > 0)) ok = 0;
        if (c) printf(" C%d=%lld", L, c);
    }
    printf("  %s\n", ok ? "PASS" : "FAIL");
    return ok;
}

static int run_tests(void) {
    graph g;
    int ok = 1;
    long long e[MAXN + 1];

    mk_empty(&g, 4); for (int i = 0; i < 4; i++) for (int j = i + 1; j < 4; j++) add_edge(&g, i, j);
    memset(e, 0, sizeof e); e[3] = 4; e[4] = 3; ok &= check_counts("K4", &g, e);

    mk_empty(&g, 6); for (int i = 0; i < 3; i++) for (int j = 3; j < 6; j++) add_edge(&g, i, j);
    memset(e, 0, sizeof e); e[4] = 9; e[6] = 6; ok &= check_counts("K3,3", &g, e);

    mk_empty(&g, 8); for (int i = 0; i < 8; i++) for (int b = 0; b < 3; b++) { int j = i ^ (1 << b); if (j > i) add_edge(&g, i, j); }
    memset(e, 0, sizeof e); e[4] = 6; e[6] = 16; e[8] = 6; ok &= check_counts("Q3", &g, e);

    mk_empty(&g, 10); for (int i = 0; i < 5; i++) { add_edge(&g, i, (i + 1) % 5); add_edge(&g, i, i + 5); add_edge(&g, 5 + i, 5 + (i + 2) % 5); }
    memset(e, 0, sizeof e); e[5] = 12; e[6] = 10; e[8] = 15; e[9] = 20; ok &= check_counts("Petersen", &g, e);

    mk_empty(&g, 14); for (int i = 0; i < 14; i++) { add_edge(&g, i, (i + 1) % 14); if (i % 2 == 0) add_edge(&g, i, (i + 5) % 14); }
    memset(e, 0, sizeof e); e[6] = 28; e[8] = 21; e[10] = 84; e[12] = 56; e[14] = 24; ok &= check_counts("Heawood", &g, e);

    /* graph6 round trip */
    char buf[1024]; graph h;
    write_g6(&g, buf); read_g6(buf, &h);
    int same = (h.n == g.n);
    for (int v = 0; v < g.n; v++) same &= (h.adj[v] == g.adj[v]);
    printf("graph6 round trip (%s): %s\n", buf, same ? "PASS" : "FAIL");
    ok &= same;
    printf(ok ? "ALL TESTS PASSED\n" : "SOME TESTS FAILED\n");
    return ok ? 0 : 1;
}

/* ---------------- filter / spectrum ---------------- */
static int pow2_status(const graph *g, int *undecided) { /* 1 if some C_{2^k}, k>=2, exists */
    *undecided = 0;
    for (int L = 4; L <= g->n; L *= 2) {
        int h = has_cyc(g, L, 4000000000LL);
        if (h == 1) return 1;
        if (h < 0) *undecided = 1;
    }
    return 0;
}

static int filter_mode(int verbose) {
    char line[16384];
    graph g;
    long long total = 0, lowdeg = 0, cex = 0, und = 0, bydiam[MAXN + 1] = {0}, freeby[MAXN + 1] = {0};
    while (fgets(line, sizeof line, stdin)) {
        size_t len = strlen(line);
        while (len && (line[len - 1] == '\n' || line[len - 1] == '\r')) line[--len] = 0;
        if (!len) continue;
        if (read_g6(line, &g) < 0) { fprintf(stderr, "skipping unreadable line\n"); continue; }
        total++;
        int mind = INF;
        for (int v = 0; v < g.n; v++) if (degree(&g, v) < mind) mind = degree(&g, v);
        if (mind < 3) lowdeg++;
        int d = diameter(&g);
        int di = d < 0 ? 0 : d;
        bydiam[di]++;
        if (has_cyc(&g, 4, 0) == 1 || has_cyc(&g, 8, 0) == 1) continue;
        freeby[di]++;
        if (verbose) printf("C4C8FREE n=%d diam=%d %s\n", g.n, d, line);
        int u;
        if (!pow2_status(&g, &u)) {
            if (u) { und++; printf("UNDECIDED %s\n", line); }
            else { cex++; printf("COUNTEREXAMPLE %s\n", line); }
        }
    }
    printf("SUMMARY graphs=%lld mindeg<3=%lld counterexamples=%lld undecided=%lld\n", total, lowdeg, cex, und);
    for (int d = 0; d <= MAXN; d++)
        if (bydiam[d]) printf("  %s %2d: graphs=%lld  no-C4-and-no-C8=%lld\n", d ? "diameter" : "disconnected", d, bydiam[d], freeby[d]);
    return 0;
}

static int spectrum_mode(void) {
    char line[16384];
    graph g;
    while (fgets(line, sizeof line, stdin)) {
        size_t len = strlen(line);
        while (len && (line[len - 1] == '\n' || line[len - 1] == '\r')) line[--len] = 0;
        if (!len || read_g6(line, &g) < 0) continue;
        int mind = INF, maxd = 0, m = 0;
        for (int v = 0; v < g.n; v++) { int dv = degree(&g, v); m += dv; if (dv < mind) mind = dv; if (dv > maxd) maxd = dv; }
        printf("n=%d m=%d deg=[%d..%d] diam=%d lengths:", g.n, m / 2, mind, maxd, diameter(&g));
        for (int L = 3; L <= g.n; L++) {
            int h = has_cyc(&g, L, 2000000000LL);
            if (h == 1) printf(" %d", L);
            else if (h < 0) printf(" %d?", L);
        }
        printf("\n");
    }
    return 0;
}

/* ---------------- annealing search ---------------- */
typedef struct {
    graph g;
    int n, m, bip, maxdiam, needconn;
    int E[MAXE][2];
} st_t;
typedef struct { int i, j, a, b, c, d; } mv_t;

static int build_random(st_t *S, const int *deg, int nx) {
    static int A[2 * MAXE], B[2 * MAXE];
    int na = 0, nb = 0;
    if (S->bip) {
        for (int v = 0; v < nx; v++) for (int k = 0; k < deg[v]; k++) A[na++] = v;
        for (int v = nx; v < S->n; v++) for (int k = 0; k < deg[v]; k++) B[nb++] = v;
        if (na != nb) return 0;
        for (int t = 0; t < 1000000; t++) {
            for (int i = nb - 1; i > 0; i--) { int j = rndint(i + 1), x = B[i]; B[i] = B[j]; B[j] = x; }
            mk_empty(&S->g, S->n);
            int ok = 1;
            for (int i = 0; i < na && ok; i++) {
                if (has_edge(&S->g, A[i], B[i])) ok = 0;
                else { add_edge(&S->g, A[i], B[i]); S->E[i][0] = A[i]; S->E[i][1] = B[i]; }
            }
            if (ok) { S->m = na; return 1; }
        }
    } else {
        for (int v = 0; v < S->n; v++) for (int k = 0; k < deg[v]; k++) A[na++] = v;
        if (na % 2) return 0;
        for (int t = 0; t < 1000000; t++) {
            for (int i = na - 1; i > 0; i--) { int j = rndint(i + 1), x = A[i]; A[i] = A[j]; A[j] = x; }
            mk_empty(&S->g, S->n);
            int ok = 1;
            for (int i = 0; i < na && ok; i += 2) {
                int a = A[i], b = A[i + 1];
                if (a == b || has_edge(&S->g, a, b)) ok = 0;
                else { add_edge(&S->g, a, b); S->E[i / 2][0] = a; S->E[i / 2][1] = b; }
            }
            if (ok) { S->m = na / 2; return 1; }
        }
    }
    return 0;
}

static int propose(st_t *S, mv_t *mv) {
    int i = rndint(S->m), j = rndint(S->m);
    if (i == j) return 0;
    int a = S->E[i][0], b = S->E[i][1], c = S->E[j][0], d = S->E[j][1];
    mv->i = i; mv->j = j; mv->a = a; mv->b = b; mv->c = c; mv->d = d;
    if (!S->bip && (rnd() & 1)) { int t = c; c = d; d = t; }
    if (a == c || a == d || b == c || b == d) return 0;
    if (has_edge(&S->g, a, d) || has_edge(&S->g, c, b)) return 0;
    del_edge(&S->g, a, b); del_edge(&S->g, c, d);
    add_edge(&S->g, a, d); add_edge(&S->g, c, b);
    S->E[i][0] = a; S->E[i][1] = d; /* bipartite: a, c stay in X */
    S->E[j][0] = c; S->E[j][1] = b;
    return 1;
}

static void undo(st_t *S, const mv_t *mv) {
    del_edge(&S->g, S->E[mv->i][0], S->E[mv->i][1]);
    del_edge(&S->g, S->E[mv->j][0], S->E[mv->j][1]);
    add_edge(&S->g, mv->a, mv->b); add_edge(&S->g, mv->c, mv->d);
    S->E[mv->i][0] = mv->a; S->E[mv->i][1] = mv->b;
    S->E[mv->j][0] = mv->c; S->E[mv->j][1] = mv->d;
}

static int struct_pen(const st_t *S) {
    if (!S->maxdiam && !S->needconn) return 0;
    int d = diameter(&S->g);
    if (d < 0) return S->needconn || S->maxdiam ? 50 : 0;
    if (S->maxdiam && d > S->maxdiam) return 4 * (d - S->maxdiam);
    return 0;
}

static long long energy1(const st_t *S) { return 6 * count_cyc(&S->g, 4) + count_cyc(&S->g, 8) + struct_pen(S); }

static int phase1(st_t *S, double deadline, long long *iters, long long *emin) {
    long long e = energy1(S), it = 0;
    if (e < *emin) *emin = e;
    double T = 1.5;
    while (e > 0) {
        if ((it & 127) == 0 && now() > deadline) { *iters += it; return 0; }
        it++;
        mv_t mv;
        if (!propose(S, &mv)) continue;
        long long en = energy1(S);
        if (en <= e || rnd01() < exp((double)(e - en) / T)) { e = en; if (e < *emin) *emin = e; }
        else undo(S, &mv);
        T *= 0.99997;
        if (T < 0.08) T = 1.5; /* reheat */
    }
    *iters += it;
    return 1;
}

static int feasible(const st_t *S) {
    if (has_cyc(&S->g, 4, 0) == 1 || has_cyc(&S->g, 8, 0) == 1) return 0;
    return struct_pen(S) == 0;
}

/* check every power of two >= 16 exactly (with a generous node budget) */
static void report_if_special(const st_t *S, int bipH) {
    char g6[4096];
    graph G = S->g;
    if (bipH) add_edge(&G, 0, 1); /* the graph H + uw */
    int und;
    int has = pow2_status(&G, &und);
    write_g6(&G, g6);
    if (!has && !und) printf("!!! COUNTEREXAMPLE FOUND (verify independently): %s\n", g6);
    else if (!has) printf("??? no power-of-two cycle found within budget (undecided): %s\n", g6);
    else printf("note: no C4/C8/C16 but a longer power-of-two cycle exists: %s\n", g6);
    fflush(stdout);
}

static void run_search(st_t *S, const int *deg, int nx, double seconds, const char *label, int bipH) {
    double t0 = now(), end = t0 + seconds;
    long long it1 = 0, evals = 0, restarts = 0, best = -1, emin = 1LL << 60, c16start = -1;
    char bestg6[4096] = "-", g6[4096];
    int bestdiam = -1;
    while (now() < end) {
        if (!build_random(S, deg, nx)) { printf("could not build a simple graph with this degree sequence\n"); return; }
        restarts++;
        double slice = seconds / 6.0; if (slice < 5) slice = 5;
        double p1end = now() + slice; if (p1end > end) p1end = end;
        if (!phase1(S, p1end, &it1, &emin)) continue;
        write_g6(&S->g, g6);
        printf("phase1 ok after %.1fs: no C4, no C8%s, diam=%d  %s\n", now() - t0, S->maxdiam ? " (diameter ok)" : "", diameter(&S->g), g6);
        fflush(stdout);
        if (S->n < 16) { report_if_special(S, bipH); best = 0; strcpy(bestg6, g6); break; }
        long long cur = count_cyc(&S->g, 16);
        c16start = cur;
        if (best < 0 || cur < best) { best = cur; strcpy(bestg6, g6); bestdiam = diameter(&S->g); }
        double ts = now();
        while (now() < end) {
            double frac = fmod((now() - ts) / 20.0, 1.0); /* 20 s cooling cycles */
            double T = 40.0 * pow(0.5 / 40.0, frac);
            mv_t mv;
            if (!propose(S, &mv)) continue;
            if (!feasible(S)) { undo(S, &mv); continue; }
            long long c = count_cyc(&S->g, 16);
            evals++;
            if (c <= cur || rnd01() < exp((double)(cur - c) / T)) cur = c;
            else { undo(S, &mv); continue; }
            if (cur < best) {
                best = cur; write_g6(&S->g, bestg6); bestdiam = diameter(&S->g);
                if (best == 0) { report_if_special(S, bipH); break; }
            }
        }
        break;
    }
    printf("RESULT %s n=%d time=%.0fs attempts=%lld phase1_iters=%lld phase1_min_energy=%lld phase2_evals=%lld C16_start=%lld best_C16=%lld diam=%d graph6=%s\n",
           label, S->n, now() - t0, restarts, it1, emin, evals, c16start, best, bestdiam, bestg6);
}

/* ---------------- gadget / necklace mode ----------------
 * A gadget K has exactly two vertices u, w of degree 2; every other vertex has degree >= 3.
 * Ring(K, N): N copies of K, with w of copy t joined to u of copy t+1 (indices mod N).
 * Every vertex of the ring has degree >= 3. A cycle that uses one connecting edge must use
 * all of them (each pair of connecting edges is an edge cut), so it crosses each copy once
 * along a u-w path: its length is N + l_1 + ... + l_N with every l_t in
 * P = {lengths of u-w paths in K}. Every other cycle lies inside one copy.
 * Hence: if K has no cycle of length 4, 8, 16, ... and, for some N, no power of two lies in
 * N + (N-fold sums of P), then Ring(K, N) is a counterexample. This mode tests that exactly. */
static void upaths(const graph *g, int v, int w, int len, set_t vis, uint64_t *P) {
    if (v == w) { *P |= 1ULL << len; return; }
    for (set_t c = g->adj[v] & ~vis; c; c &= c - 1) {
        int x = __builtin_ctzll(c);
        upaths(g, x, w, len + 1, vis | BIT(x), P);
    }
}

#define RW 4096 /* bitset words for the sumsets: sums up to 262143 */
/* smallest N in [1, nmax] whose ring lengths avoid every power of two (>= 4); 0 if none */
static int ring_first_good_N(uint64_t P, int nmax) {
    static uint64_t cur[RW + 1], nxt[RW + 1];
    int b = 63 - __builtin_clzll(P);
    if ((long long)nmax * b > (long long)(RW - 2) * 64) nmax = (int)(((long long)(RW - 2) * 64) / b);
    memset(cur, 0, sizeof cur);
    cur[0] = 1; /* zero copies: the empty sum */
    for (int N = 1; N <= nmax; N++) {
        int words = (N * b) / 64 + 1;
        memset(nxt, 0, sizeof(uint64_t) * (words + 1));
        for (int l = 1; l < 64; l++)
            if ((P >> l) & 1)
                for (int i = 0; i <= words; i++) {
                    uint64_t v = cur[i] << l;
                    if (i) v |= cur[i - 1] >> (64 - l);
                    nxt[i] |= v;
                }
        memcpy(cur, nxt, sizeof(uint64_t) * (words + 1));
        int bad = 0;
        for (int j = 2; j < 40 && !bad; j++) {
            long long t = (1LL << j) - N; /* ring length 2^j  <=>  sum of path lengths = 2^j - N */
            if (t < 0) continue;
            if (t > (long long)N * b) break;
            if ((cur[t >> 6] >> (t & 63)) & 1) bad = 1;
        }
        if (!bad) return N;
    }
    return 0;
}

static int gadget_mode(int nmax, int verbose) {
    char line[16384], best_line[16384] = "-";
    graph g;
    long long total = 0, two = 0, noc48 = 0, internal_ok = 0, und = 0, thin = 0, works = 0;
    double best_ratio = 1e9;
    int best_a = 0, best_b = 0;
    while (fgets(line, sizeof line, stdin)) {
        size_t len = strlen(line);
        while (len && (line[len - 1] == '\n' || line[len - 1] == '\r')) line[--len] = 0;
        if (!len || read_g6(line, &g) < 0) continue;
        total++;
        int u = -1, w = -1, c2 = 0, ok = 1;
        for (int v = 0; v < g.n; v++) {
            int d = degree(&g, v);
            if (d < 2) ok = 0;
            if (d == 2) { c2++; if (u < 0) u = v; else w = v; }
        }
        if (!ok || c2 != 2) continue;
        two++;
        if (has_cyc(&g, 4, 0) == 1 || has_cyc(&g, 8, 0) == 1) continue;
        noc48++;
        int bad = 0, un = 0;
        for (int L = 16; L <= g.n && !bad; L *= 2) {
            int h = has_cyc(&g, L, 4000000000LL);
            if (h == 1) bad = 1;
            if (h < 0) un = 1;
        }
        if (bad) continue;
        if (un) { und++; printf("UNDECIDED %s\n", line); continue; }
        internal_ok++;
        uint64_t P = 0;
        upaths(&g, u, w, 0, BIT(u), &P);
        if (!P) { works++; printf("!!! NECKLACE COUNTEREXAMPLE (u,w disconnected) %s\n", line); continue; }
        int a = __builtin_ctzll(P), b = 63 - __builtin_clzll(P);
        double ratio = (double)(b + 1) / (a + 1);
        if (ratio < 2) thin++;
        if (ratio < best_ratio) { best_ratio = ratio; best_a = a; best_b = b; strcpy(best_line, line); }
        int N = ring_first_good_N(P, nmax);
        if (verbose) {
            printf("gadget %s u=%d w=%d u-w path lengths:", line, u, w);
            for (int l = 0; l < 64; l++) if ((P >> l) & 1) printf(" %d", l);
            printf("  -> %s\n", N ? "RING WORKS" : "every ring size hits a power of two");
        }
        if (N) { works++; printf("!!! NECKLACE COUNTEREXAMPLE gadget=%s u=%d w=%d N=%d (verify independently)\n", line, u, w, N); fflush(stdout); }
    }
    printf("SUMMARY graphs=%lld two-deg2-gadgets=%lld no-C4-no-C8=%lld no-internal-2^k-cycle=%lld undecided=%lld "
           "thin(ratio<2)=%lld necklace-counterexamples=%lld best_ratio=(b+1)/(a+1)=%.3f [a=%d b=%d] %s\n",
           total, two, noc48, internal_ok, und, thin, works, best_ratio < 1e8 ? best_ratio : 0.0, best_a, best_b, best_line);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: see header of eg.c\n"); return 1; }
    if (!strcmp(argv[1], "test")) return run_tests();
    if (!strcmp(argv[1], "filter")) return filter_mode(argc > 2 && !strcmp(argv[2], "-v"));
    if (!strcmp(argv[1], "spectrum")) return spectrum_mode();
    if (!strcmp(argv[1], "gadget")) {
        int nmax = 1000, verbose = 0;
        for (int i = 2; i < argc; i++) { if (!strcmp(argv[i], "-v")) verbose = 1; else nmax = atoi(argv[i]); }
        return gadget_mode(nmax, verbose);
    }

    static st_t S;
    int deg[MAXN];
    memset(&S, 0, sizeof S);

    if (!strcmp(argv[1], "hsearch") && argc >= 5) {
        int n = atoi(argv[2]);
        double secs = atof(argv[3]);
        rs ^= (uint64_t)atoll(argv[4]) * 0x2545F4914F6CDD1DULL; if (!rs) rs = 1;
        if (n < 8 || n > MAXN) { fprintf(stderr, "N must be in 8..%d\n", MAXN); return 1; }
        int a = (n % 2 == 0) ? n / 2 : (n + 1) / 2;
        for (int v = 0; v < n; v++) deg[v] = 3;
        deg[0] = deg[1] = 2;
        if (n % 2 == 0) { deg[2] = deg[3] = 4; } else { deg[a] = 4; }
        S.n = n; S.bip = 1; S.maxdiam = 0; S.needconn = 0;
        printf("hsearch n=%d |X|=%d |Y|=%d (u=0,w=1 deg 2; %s)\n", n, a, n - a, n % 2 == 0 ? "X-vertices 2,3 deg 4" : "one Y-vertex deg 4");
        run_search(&S, deg, a, secs, "H", 1);
        return 0;
    }
    if (!strcmp(argv[1], "gsearch") && argc >= 6) {
        double secs = atof(argv[2]);
        rs ^= (uint64_t)atoll(argv[3]) * 0x2545F4914F6CDD1DULL; if (!rs) rs = 1;
        int maxdiam = atoi(argv[4]);
        int n = 0;
        char spec[256]; strncpy(spec, argv[5], 255); spec[255] = 0;
        for (char *tok = strtok(spec, ","); tok; tok = strtok(NULL, ",")) {
            int d, k;
            if (sscanf(tok, "%dx%d", &d, &k) != 2 || d < 3) { fprintf(stderr, "bad DEGSPEC\n"); return 1; }
            for (int i = 0; i < k && n < MAXN; i++) deg[n++] = d;
        }
        S.n = n; S.bip = 0; S.maxdiam = maxdiam; S.needconn = 1;
        printf("gsearch n=%d degspec=%s maxdiam=%d\n", n, argv[5], maxdiam);
        run_search(&S, deg, 0, secs, "G", 0);
        return 0;
    }
    fprintf(stderr, "unknown mode / missing arguments\n");
    return 1;
}
